void solve(int W, int H, int N, float *input, float *output) 
{
	for (int i = 0; i < H; i++) {
        for (int j = 0; j < W; j++) {
            float tmp = 0;
            for (int ii = 0; ii < N; ii++)
                for (int jj = 0; jj < N; jj++)
                    tmp += input[(i + ii) * (W + N - 1) + j + jj];

            tmp = tmp / (N * N);
            output[i * W + j] = tmp;
        }
    }
}
